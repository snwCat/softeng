﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using zh3_al0psy.BookModels;

namespace zh3_al0psy
{
    public partial class UserControl3 : UserControl
    {
        FunnyDatabaseContext context = new FunnyDatabaseContext();
        public UserControl3()
        {
            InitializeComponent();
        }

        private void UserControl3_Load(object sender, EventArgs e)
        {
            listBox1.DataSource = (from x in context.Books
                                   select x).ToList();
            listBox1.DisplayMember = "Title";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            listBox1.DataSource = (from x in context.Books
                                   where x.Title.Contains(textBox1.Text)
                                   select x).ToList();
        }
    }
}
