﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using zh3_al0psy.BookModels;

namespace zh3_al0psy
{
    public partial class UserControl2 : UserControl
    {
        FunnyDatabaseContext context = new FunnyDatabaseContext();
        public UserControl2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (bookBindingSource.Current != null)
            {
                var b = MessageBox.Show("Biztosan törölni szeretné?", "Törlés megerősítése", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (b == DialogResult.Yes)
                {
                    bookBindingSource.Remove(bookBindingSource.Current);
                    context.SaveChanges();
                }
            }
        }

        private void UserControl2_Load(object sender, EventArgs e)
        {
            bookBindingSource.DataSource = context.Books.ToList();
        }
    }
}


